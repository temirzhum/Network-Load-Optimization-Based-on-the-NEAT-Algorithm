import neat
import visualize

config = neat.Config(neat.DefaultGenome,neat.DefaultReproduction,neat.DefaultSpeciesSet,neat.DefaultStagnation,'./config_1')

population = neat.Checkpointer.restore_checkpoint(
    './models/prob_work_4500'
)


genomes=[]
for genome_id, genome in population.population.items():
        print(f"id: {genome_id}, fitness: {genome.fitness}")
        genomes.append(genome)

a=input('What model ')

net=genomes[int(a)]

visualize.draw_net(config,net,view=True) #visualise.py was downloaded from neat-python github page