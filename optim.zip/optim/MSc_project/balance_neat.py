import neat
import course
import time
import weight_pred_path
import course_pred_path

import numpy as np
import weight_rand_path

dict={
    'sim_avg_load_lte':(0,1),
    'sim_avg_load_5G':(0,1),
    'sim_max_load':(0,1),
    'sim_throughput':(0,8),
    'sim_handovers':(0,500),
    'sim_avg_sat':(0,1),
    'sim_discon':(0,5000)
}


def min_max(numbers):
    new_list=[]
    for i in numbers:
        n=(i-min(numbers))/(max(numbers)-min(numbers))
        new_list.append(n)
    return new_list



def scale(n,mini_max):
    min_val,max_val=mini_max
    return max(0.0,min(1.0,(n-min_val)/(max_val-min_val)))



def eval_genomes(genomes, config):
    for genome_id, genome in genomes:
        net=neat.nn.FeedForwardNetwork.create(genome,config)




        start = time.time()
        ping_pong_history,disconnected_users_total,sim_avg_load_lte,sim_avg_load_5G,sim_max_load,sim_avg_throghput,handovers,sim_avg_sat=course.start(net,False)
        end = time.time()




        new_load_lte=scale(sim_avg_load_lte,dict['sim_avg_load_lte'])
        new_load_5G=scale(sim_avg_load_5G,dict['sim_avg_load_5G'])

        new_max_load=scale(sim_max_load,dict['sim_max_load'])
        new_throghput=scale(sim_avg_throghput,dict['sim_throughput'])
        new_hand=scale(handovers,dict['sim_handovers'])
        new_sat=scale(sim_avg_sat,dict['sim_avg_sat'])
        new_discon=scale(disconnected_users_total,dict['sim_discon'])

        fitness=(2*new_sat + new_load_5G - new_load_lte- new_max_load- 0.2*new_hand- 3*new_discon)


        print(f"\nTIME FOR CODE IN SECONDS {end-start}")
        print(f"discon users {disconnected_users_total}, new_discon {new_discon} ")       
        print(f"sat is {sim_avg_sat}, scaled sat is {new_sat} ") 
        print(f"fitness is {fitness}") 

        genome.fitness=fitness



def main(f):
    config = neat.Config(neat.DefaultGenome, neat.DefaultReproduction,
                                    neat.DefaultSpeciesSet, neat.DefaultStagnation,
                                    "config_1")
    
    prob_of_weak=0.2  
    mut_rate_mul=0.2    
    population = neat.Population(config,prob_of_weak,mut_rate_mul)
    name='./models/prob_work_'+str(f)
    population.add_reporter(neat.Checkpointer(50,filename_prefix=name))

    start = time.time()
    winner = population.run(eval_genomes, 100)   
    end = time.time()
    print(f"\n----MAIN 1--TIME FOR evolution {end-start} seconds, or {(end-start)/60} minutes, or {((end-start)/60)/60} hours")




def test_1():
    
    pop = neat.Checkpointer.restore_checkpoint('./models/prob_work_5500')

    config  = neat.Config(neat.DefaultGenome, neat.DefaultReproduction,
                             neat.DefaultSpeciesSet, neat.DefaultStagnation,
                             'config_1')
    
    runners=[]
    hunter=[]
    pp=0
    for _, genome in pop.population.items():
        print(f"number: {pp}, fitness: {genome.fitness}")
        pp+=1

  

    best_genome = None
    best_fitness = float('-inf')
    genomes=[]
    for genome_id, genome in pop.population.items():
        genomes.append(genome)

    user=input("What member")
    net = neat.nn.FeedForwardNetwork.create(genomes[int(user)], config)
    ping_pong_history,disconnected_users_total,sim_avg_load_lte,sim_avg_load_5G, sim_max_load, sim_avg_throghput, handovers,sim_avg_sat= course.start(net,True)   #course_for_single_test_animation
           
    new_load_lte=scale(sim_avg_load_lte,dict['sim_avg_load_lte'])
    new_load_5G=scale(sim_avg_load_5G,dict['sim_avg_load_5G'])

    new_max_load=scale(sim_max_load,dict['sim_max_load'])
    new_throghput=scale(sim_avg_throghput,dict['sim_throughput'])
    new_hand=scale(handovers,dict['sim_handovers'])
    new_sat=scale(sim_avg_sat,dict['sim_avg_sat'])


    fitness=(2*new_sat-new_load_lte+new_load_5G*0.5-new_max_load-0.2*new_hand)


    print(f'Fitness {fitness}')
    print(f"sim_avg_load_lte {sim_avg_load_lte}, sim_avg_load_5G {sim_avg_load_5G}, sim_max_load {sim_max_load}, \
sim_avg_throghput {sim_avg_throghput}, handovers {handovers},sim_avg_sat {sim_avg_sat}")
 
    print(f"discon users {disconnected_users_total}")

    

def obtain_res_neat(names):
        best_ids=[]

        double_best_fitness_fin=[]
        double_best_traf_fin=[]
        double_best_sat_fin=[]
        double_dis_us_fin=[]
        double_times_fin=[]
        double_ping_pong_hist_fin=[]

        
        for i in range(6):
            strp=time.time()
            for what in range(20):
                best_fitness_fin=[]
                best_traf_fin=[]
                best_sat_fin=[]
                dis_us_fin=[]
                times_fin=[]
                ping_pong_hist_fin=[]
                pop = neat.Checkpointer.restore_checkpoint(names[i])
        
                config  = neat.Config(neat.DefaultGenome, neat.DefaultReproduction,
                                            neat.DefaultSpeciesSet, neat.DefaultStagnation,
                                            'config_1')
        
                best_genome = None
                best_fitness = float('-inf')
                genomes=[]
                for genome_id, genome in pop.population.items():
                        genomes.append(genome)
        
            
                fitnesses=[]
                best__fit=-20
                disconnected_users_total_list=[]
                sim_avg_satisfactions=[]
                sim_traf=[]
                times=[]
                ping_pong_hist=[]
        
                for blk in range(50):
                    try:
                        start=time.time()
                        net = neat.nn.FeedForwardNetwork.create(genomes[int(blk)], config)
                        ping_pong_history,disconnected_users_total,sim_avg_load_lte,sim_avg_load_5G, sim_max_load, sim_avg_throghput, handovers,sim_avg_sat = course.start(net,False)
            
                        new_load_lte=scale(sim_avg_load_lte,dict['sim_avg_load_lte'])
                        new_load_5G=scale(sim_avg_load_5G,dict['sim_avg_load_5G'])
            
                        new_max_load=scale(sim_max_load,dict['sim_max_load'])
                        new_throghput=scale(sim_avg_throghput,dict['sim_throughput'])
                        new_hand=scale(handovers,dict['sim_handovers'])
                        new_sat=scale(sim_avg_sat,dict['sim_avg_sat'])
            
                        new_discon=scale(disconnected_users_total,dict['sim_discon'])
                        fitness=(2*new_sat + new_load_5G - new_load_lte- new_max_load- 0.2*new_hand- 3*new_discon)
            
                        fitnesses.append(fitness)
                        disconnected_users_total_list.append(disconnected_users_total)
                        ping_pong_hist.append(ping_pong_history)
                        sim_avg_satisfactions.append(sim_avg_sat)
                        sim_traf.append(sim_avg_throghput)
                        time.sleep(1)
                        end = time.time()
                        times.append(end-start)
                    except:
                        continue
        
                best_fit=-10
                best_id=-10
                best_sat=-10
                best_traf=-10
                dis_us_1=-10
                dis_us=0
                best_time=0
                best_ping_pong=0
        
        
                for j in range(len(fitnesses)):
                    if fitnesses[j]>best_fit:
                        best_fit=fitnesses[j]
                        best_id=j
                        best_traf=sim_traf[j]
                        best_sat=sim_avg_satisfactions[j]
                        dis_us_1=disconnected_users_total_list[j]
                        best_time=times[j]
                        best_ping_pong=ping_pong_hist[j]
        
               
                best_ids.append(best_id)
                best_fitness_fin.append(best_fit)
                best_traf_fin.append(best_traf)
                best_sat_fin.append(best_sat)
                dis_us_fin.append(dis_us_1)
                times_fin.append(best_time)
                ping_pong_hist_fin.append(best_ping_pong)
               

            double_best_fitness_fin.append(best_fitness_fin)
            double_best_traf_fin.append(best_traf_fin)
            double_best_sat_fin.append(best_sat_fin)
            double_dis_us_fin.append(dis_us_fin)
            double_times_fin.append(times_fin)
            double_ping_pong_hist_fin.append(ping_pong_hist_fin)

            und=time.time()
            print(f'Time for one of the models {und-strp}')

        avg_fit=[]
        avg_traf=[]
        avg_sat=[]
        avg_us=[]
        avg_times=[]
        avg_ping_pong=[]
        import numpy as np
        for mnm in range(6):
            avg_fit.append(np.mean(double_best_fitness_fin[mnm]))
            avg_traf.append(np.mean(double_best_traf_fin[mnm]))
            avg_sat.append(np.mean(double_best_sat_fin[mnm]))
            avg_us.append(np.mean(double_dis_us_fin[mnm]))
            avg_times.append(np.mean(double_times_fin[mnm]))
            avg_ping_pong.append(np.mean(double_ping_pong_hist_fin[mnm]))


        for k in range(6):
            print(f"name {names[k]}, fitness of the member {avg_fit[k]}\
traf {avg_traf[k]}, satisfaction {avg_sat[k]}, disconnncted users {avg_us[k]}\
time {avg_times[k]}, ping pong {avg_ping_pong[k]}")

        return np.mean(avg_fit)



def obtain_res_rein():
        avg_fit=[]
        avg_traf=[]
        avg_sat=[]
        avg_us=[]
        avg_times=[]
        avg_ping_pong=[]
        for sim in range(20):
            print(f'sim {sim}')
            sturt=time.time()
            ping_pong_history,disconnected_users_total,sim_avg_load_lte,sim_avg_load_5G, sim_max_load, sim_avg_throghput, handovers,sim_avg_sat = course_pred_path.start(None,False)
            time.sleep(1)
            end = time.time()
            ttt=end-sturt
        
            new_load_lte=scale(sim_avg_load_lte,dict['sim_avg_load_lte'])
            new_load_5G=scale(sim_avg_load_5G,dict['sim_avg_load_5G'])
                
            new_max_load=scale(sim_max_load,dict['sim_max_load'])
            new_throghput=scale(sim_avg_throghput,dict['sim_throughput'])
            new_hand=scale(handovers,dict['sim_handovers'])
            new_sat=scale(sim_avg_sat,dict['sim_avg_sat'])
                
            new_discon=scale(disconnected_users_total,dict['sim_discon'])
            fitness=(2*new_sat + new_load_5G - new_load_lte- new_max_load- 0.2*new_hand- 3*new_discon)
        
            print(f"fitness of the algorithm {fitness}\
traf {sim_avg_throghput}, satisfaction {sim_avg_sat}, disconnncted users {disconnected_users_total}\
time {ttt}, ping pong {ping_pong_history}")
            
            avg_fit.append(fitness)
            avg_traf.append(sim_avg_throghput)
            avg_sat.append(sim_avg_sat)
            avg_us.append(disconnected_users_total)
            avg_times.append(ttt)
            avg_ping_pong.append(ping_pong_history)
            if sim%5==0:
                print(f"Sub res N {sim}")
                double_best_fitness_fin=np.mean(avg_fit)
                double_best_traf_fin=np.mean(avg_traf)
                double_best_sat_fin=np.mean(avg_sat)
                double_dis_us_fin=np.mean(avg_us)
                double_times_fin=np.mean(avg_times)
                double_ping_pong_hist_fin=np.mean(avg_ping_pong)
                print(f"fitness of the algorithm {double_best_fitness_fin}\
traf {double_best_traf_fin}, satisfaction {double_best_sat_fin}, \
disconnncted users {double_dis_us_fin}, time {double_times_fin}, ping pong {double_ping_pong_hist_fin}")
                         

        double_best_fitness_fin=np.mean(avg_fit)
        double_best_traf_fin=np.mean(avg_traf)
        double_best_sat_fin=np.mean(avg_sat)
        double_dis_us_fin=np.mean(avg_us)
        double_times_fin=np.mean(avg_times)
        double_ping_pong_hist_fin=np.mean(avg_ping_pong)
        print(f"\n FINAL \n")
        print(f"fitness of the algorithm {double_best_fitness_fin}\
 traf {double_best_traf_fin}, satisfaction {double_best_sat_fin}, \
 disconnncted users {double_dis_us_fin}, time {double_times_fin}, ping pong {double_ping_pong_hist_fin}")
        
        

def obtain_res_weight():
        avg_fit=[]
        avg_traf=[]
        avg_sat=[]
        avg_us=[]
        avg_times=[]
        avg_ping_pong=[]
        for sim in range(20):
            sturt=time.time()
            ping_pong_history,disconnected_users_total,sim_avg_load_lte,sim_avg_load_5G, sim_max_load, sim_avg_throghput, handovers,sim_avg_sat = course.start(None,False)
            time.sleep(1)
            end = time.time()
            ttt=end-sturt
        
            new_load_lte=scale(sim_avg_load_lte,dict['sim_avg_load_lte'])
            new_load_5G=scale(sim_avg_load_5G,dict['sim_avg_load_5G'])
                
            new_max_load=scale(sim_max_load,dict['sim_max_load'])
            new_throghput=scale(sim_avg_throghput,dict['sim_throughput'])
            new_hand=scale(handovers,dict['sim_handovers'])
            new_sat=scale(sim_avg_sat,dict['sim_avg_sat'])
                
            new_discon=scale(disconnected_users_total,dict['sim_discon'])
            fitness=(2*new_sat + new_load_5G - new_load_lte- new_max_load- 0.2*new_hand- 3*new_discon)
            avg_fit.append(fitness)
            avg_traf.append(sim_avg_throghput)
            avg_sat.append(sim_avg_sat)
            avg_us.append(disconnected_users_total)
            avg_times.append(ttt)
            avg_ping_pong.append(ping_pong_history) 

            print(f"fitness of the algorithm {fitness} \
traf {sim_avg_throghput}, satisfaction {sim_avg_sat}, \
disconnncted users {disconnected_users_total}, time {ttt}, ping pong {ping_pong_history}")
                  
        double_best_fitness_fin=np.mean(avg_fit)
        double_best_traf_fin=np.mean(avg_traf)
        double_best_sat_fin=np.mean(avg_sat)
        double_dis_us_fin=np.mean(avg_us)
        double_times_fin=np.mean(avg_times)
        double_ping_pong_hist_fin=np.mean(avg_ping_pong)
        print(f"\n FINAL \n")
        print(f"fitness of the algorithm {double_best_fitness_fin}\
 traf {double_best_traf_fin}, satisfaction {double_best_sat_fin}, \
 disconnncted users {double_dis_us_fin}, time {double_times_fin}, ping pong {double_ping_pong_hist_fin}")

        
def run():
        import multiprocessing
        proc = []
        for i in range(6):
            n = str(i) + '_bezumie_999999_'
            proc.append(multiprocessing.Process(target=main, args=(n, )))

        for j in proc:
            j.start()
    
        for l in proc:
            l.join()

if __name__ == "__main__":
    """
    names=['./models/prob_work_5'+str(500),'./models/prob_work_4'+str(500),
            './models/prob_work_3'+str(500),'./models/prob_work_2'+str(500),
            './models/prob_work_1'+str(500),'./models/prob_work_0'+str(500)]
    
    find_best_model(names)




    species=[]
    fitnesses=[]
    for k in range(6):
        print(f'Run n {k}')
        g=(k+1)*50
        names=['./models/prob_work_5'+str(g),'./models/prob_work_4'+str(g),
            './models/prob_work_3'+str(g),'./models/prob_work_2'+str(g),
            './models/prob_work_1'+str(g),'./models/prob_work_0'+str(g)]
        fit=obtain_res_neat(names)
        fitnesses.append(fit)
        species_counts = []

        for name in names:
            p=neat.Checkpointer.restore_checkpoint(name)

            n_species=len(p.species.species)

            species_counts.append(n_species)
        species.append(np.mean(species_counts))
        print('Generation:', g,'Species:', species_counts,'Average:', np.mean(species_counts))

    for pppp in range(10):
         print(f"{(pppp+1)*50} {fitnesses[pppp]}\n ")
"""
    #obtain_res_rein()

    #obtain_res_weight()

    
    #main("l")
    test_1()
    #run()  



    #run()


    
    
    
    #main()
 

    #test_1()  #To run just hunter/runner game  0.9132428333094881
