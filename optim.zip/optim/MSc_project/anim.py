import numpy as np
import matplotlib

import matplotlib.pyplot as plt


class anim():
    def __init__(self,user_history,load_history,st_x,st_y,st_type,st_rad,map):
        self.user_history=user_history
        self.load_history=load_history
        self.st_x=st_x
        self.st_y=st_y
        self.st_type=st_type
        self.st_rad=st_rad
        self.map_size=map
        self.num_steps=len(user_history)
        self.num_stations=len(st_x)
        sh=np.shape(user_history)
        self.num_users=sh[1]

    def station(self,load,st_type):
        if st_type=='5G':
            return 'blue'
        if load<0.4:
            return 'green'
        if load<0.7:
            return 'orange'
        return 'red'

    def circle(self,st_type):
        return 'green' if st_type=='LTE' else 'yellow'

    def circle_radius(self,st_type):
        return 500 if st_type=='LTE' else 200

    def working(self):
        plt.ion()
        fig=plt.figure(figsize=(8,8))
        ax=fig.add_subplot(111)

        for step in range(self.num_steps):
            plt.clf()
            ax=fig.add_subplot(111)
            plt.xlim(0,self.map_size)
            plt.ylim(0,self.map_size)
            plt.title(f'{step+1}/{self.num_steps}')
            plt.xlabel('X')
            plt.ylabel('Y')

            loads=self.load_history[step]
            users=self.user_history[step]

            for i in range(self.num_stations):
                color=self.station(loads[i],self.st_type[i])
               
                if self.st_type[i]=='LTE':
                     marker='^' 
                else:
                    marker='s'

                circ=plt.Circle((self.st_x[i],self.st_y[i]),self.circle_radius(self.st_type[i]),
                    color=self.circle(self.st_type[i]),alpha=0.2,zorder=1)
                ax.add_patch(circ)

                plt.plot(self.st_x[i],self.st_y[i],marker=marker,color=color,markersize=12,zorder=3)

              

            for j in range(self.num_users):
                id,ux,uy,sid,disconnected=users[j]
                sid=int(sid)

                color='red' if disconnected else 'purple'
                plt.plot(ux,uy,'o',color=color,markersize=6)

                if not disconnected and 0<=sid<self.num_stations:
                    plt.plot([ux,self.st_x[sid]],[uy,self.st_y[sid]],color='gray',linewidth=0.5,alpha=0.5)

            plt.legend(loc='upper right',fontsize=7)

            plt.draw()
            plt.pause(0.05)

        plt.ioff()
        plt.show()