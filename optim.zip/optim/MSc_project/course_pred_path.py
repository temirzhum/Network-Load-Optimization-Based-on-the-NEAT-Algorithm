
import random

import networkx as nx
import numpy as np
import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt

import copy
from anim import anim
import time
import math
import neat
import copy
lte_r=500
lte_pow=46
n_lte=7
lte_prb=100
lte_freq_ghz=2.1
lte_bandwidth= 20


r_5G=200
p_5G=30
prb_5G=2500
n_5G=21
freq_5g_ghz=28
bandwidth_5g=500


one_prb=180*1000 
n_user=100


min_speed=1
max_speed=160
min_traf=1.0
max_traf=8.0

  
min_sinr=-8
max_sinr=25

min_hom=0
max_hom=20
sinr_threashhold=-10
load_threashold=0.5

map=1800
steps=200


noise_figure=6       
cons = -174 
sinr_max=25
noice_prb=cons+10*np.log10(one_prb)+noise_figure
ce=[
    0.1,0.1523,0.2344,0.3770,0.6016,0.8770,
    1.1758,1.4766,1.9141,2.4063,2.7305,3.3223,
    3.9023,4.5234,5.1152,5.5547
]
sinr_table=[
    (-np.inf,-6.7),(-6.7, -4.7),(-4.7 ,-2.3),(-2.3 , 0.2),(0.2, 2.4),(2.4 , 4.3),(4.3 ,5.9),(5.9, 8.1),
    (8.1,10.3),(10.3 , 11.7),(11.7, 14.1),(14.1 ,16.3),(16.3, 18.7),(18.7 , 21.0),(21.0 , 22.7),(22.7 , np.inf)
]
sinr_to_se_table=[
    (0,0,0),(0,0,0),(0,0,0),(0,0,0),(0,0,0),(0,0,0),(0,0,0),(0,0,0),
    (0,0,0),(0,0,0),(0,0,0),(0,0,0),(0,0,0),(0,0,0),(0,0,0),(0,0,0)
]
for i in range (len(sinr_table)):
    sinr_to_se_table[i]=ce[i],sinr_table[i][0],sinr_table[i][1]


time_in_step=0.5 
ttt_min=0.5
ttt_base=2.0
ttt_max=5.12
ttt_p=0.04
ttt_q=0.1    


mini_max_dict={
    'is_5G':(0,1),
    'load':(0,1),
    'avg_load':(0,1),
    'max_load':(0,1),
    'throughput':(1,8),
    'avg_throughput':(1,8),
    'sinr':(-8,25),
    'avg_sinr':(-8,25),
    'handovers_prev_step':(0,20),
}





class BaseStation:

    def __init__(self, station_id, type, x, y):
        
        self.station_id=station_id
        self.type=type
        self.x=x
        self.y=y
        self.CIO=0
        self.delta_ttt=0.0
        if type=='LTE':
            self.radius=lte_r
            self.power=lte_pow
            self.prb_total=lte_prb
            self.freq=lte_freq_ghz
            self.bandwidth=lte_bandwidth
        else:  
            self.radius=r_5G
            self.power=p_5G
            self.prb_total=prb_5G
            self.freq=freq_5g_ghz
            self.bandwidth=bandwidth_5g

        self.prb_used=0

        self.connected_users=[]

    def get_load(self):

        self.prb_used=0
        
        if self.type=="LTE":
            self.prb_total=lte_prb
        else:
            self.prb_total=prb_5G
        all_se=0
        se=0
        if len(self.connected_users)==0:
            return 0.0
 

        traffics=[]
        don=False
        b=0
        #print(f"used prb before loop {self.prb_used}")
        demand={}
        already_happened=False                           
        for user in self.connected_users:
            for i in sinr_to_se_table:
                if user.current_sinr>i[1] and user.current_sinr<i[2]:
                    b+=1

                    se=i[0]
                    user.se=se
                    one_prb_throughput=one_prb*se
                    user_prb=math.ceil(user.traf_req*1_000_000/one_prb_throughput)
                    wanted=user_prb
                    demand[user]=wanted  
                        
                    if user_prb+self.prb_used>self.prb_total:
                       
                        user_prb=max(0, self.prb_total-self.prb_used)
                        if user_prb==0 and already_happened==False: 
                            already_happened=True 
                            equal_prb=np.floor(self.prb_total/len(self.connected_users))
                            user_prb=equal_prb
                            for i in self.connected_users:
                                
                                old_prb=i.prb
                                if old_prb==0:
                                    old_prb=1
                                old_sat=i.sat
                                i.prb=equal_prb

                                wanted_i=demand.get(i, old_prb)      
                                
                                if wanted_i>0:
                                    new_sat=min(1.0, equal_prb/wanted_i) 

                                else:
                                    new_sat=0.0 
                                i.sat=new_sat

                        elif user_prb==0 and already_happened==True: 
                            user_prb=equal_prb    
                                 
                        self.prb_used+=user_prb        
                        user.sat=min(1.0, user_prb/wanted)
                        user.prb=user_prb
                        user.throughput=user.sat*user.traf_req
                    
                    else:
                        self.prb_used+=user_prb
                        user.prb=user_prb
                        user_prb_throughput=user_prb*se
                        user.throughput=user.sat*user.traf_req
                        user.sat=1.0
                    
                    
                
        self.get_used_prb()
                   
        load=self.prb_used/self.prb_total

        
        
       
        return load

    def get_used_prb(self):
        self.prb_used=0
        for user in self.connected_users:
            self.prb_used+=user.prb
        


    def is_overloaded(self):
        return self.get_load()>load_threashold

    def add_user(self, user):
        self.connected_users.append(user)
        user.is_discon=False
        

    def remove_user(self, user):
        if user in self.connected_users:
            self.connected_users.remove(user)
            self.prb_used=self.prb_used-user.prb
            user.is_discon=True
            user.prb=0
            user.throughput=0
            user.serving_station_id=-1

            

class User:

    def __init__(self, user_id, x, y, target_x, target_y, speed_kmh,traffic_req):

        self.steps_connected=0
        self.steps_connected_list=[]

        self.user_id=user_id
        self.x=x
        self.y=y
        self.target_x=target_x
        self.target_y=target_y
        self.speed_kms=speed_kmh
        self.speed_ms=(speed_kmh * 1000)/3600*time_in_step
        self.traf_req=traffic_req
        self.prb=0
        self.se=0
        self.serving_station_id=-1
        self.current_sinr=0.0
        self.throughput=0.0
        self.path_x=[x]
        self.path_y=[y]
        self.ttt_timer= 0.0
        self.ttt_t=0.0
        self.f_wf_prev= 0.0 
        self.is_discon=True
        self.del_ttt=0.0
        self.sinr=0.0
        self.sat=0.0
    def move(self):

        
        
                dx=self.target_x- self.x
                dy=self.target_y-self.y
                distance = math.sqrt(dx**2+ dy**2)  
        
                if distance<self.speed_ms:
                    
                    self.x=self.target_x
                    self.y=self.target_y
                    if self.target_x==1799:
                        self.target_x=1
                    elif self.target_x==1:
                        self.target_x=1799
                    self.target_y+=10
                else:
                    
                    self.x+=(dx/distance)*self.speed_ms
                    self.y+=(dy/distance)*self.speed_ms
        
                self.path_x.append(self.x)
                self.path_y.append(self.y)

def calc_rsrp(station,dist):
    d_0 = 1
    
   
    
    l_0 = 20*math.log10(d_0) + 20* math.log10(station.freq * 1_000_000_000) - 147.55
  
  
    path_loss_ex = 2.0

    l_d = l_0 + 10 * path_loss_ex * math.log10(max(dist, d_0))
    
    received_power = station.power - l_d
    if station.type=='LTE':
        rb=lte_prb
    else:
        rb=prb_5G
    rsrp = received_power - 10*math.log10(12*rb)
   
    return rsrp

def calculate_sinr(user, station, all_stations):

    distance=math.sqrt((user.x-station.x)**2+(user.y-station.y)**2)
    received_power=calc_rsrp(station,distance)

    signal= 10 ** (received_power / 10)
    
    interference = 0  
    for other in all_stations:
        if other.station_id != station.station_id:
            if other.freq==station.freq:
                dist=math.sqrt((user.x-other.x)**2+(user.y-other.y)**2)
                new_received_power=calc_rsrp(other, dist)
                interference+=10**(new_received_power/10)
    
       
    bandwidth = station.bandwidth * 1_000_000

    noise_dbm = (-174 +10*math.log10(bandwidth) +noise_figure)
    
    
    noise = 10**(noise_dbm / 10)
 
    sinr_lin=signal/(interference+noise)
    sinr_db=10*math.log10(sinr_lin)
   
    if sinr_db<min_sinr:
        sinr_db=min_sinr
    if sinr_db>max_sinr:
        sinr_db=max_sinr
    user.sinr=sinr_db
  
    return sinr_db

def automatic_weight_function(fs):
    
    f_y=fs[0]
    f_prb=fs[1]
    f_v=fs[2]
    total=(1-f_y)+(1-f_prb)+(1-f_v)
    w_y=f_y/total
    w_prb=f_prb/total
    w_v=f_v/total
    return [w_y,w_prb,w_v]


def find_target_station(user, stations):
    distances=[]
    ncl=[]
    available_stantions=[]
    for i in stations:
        user_x=user.x
        user_y=user.y
        station_x=i.x
        station_y=i.y
        dist=math.sqrt((user_x-station_x)**2+(user_y-station_y)**2)
        load_st=i.get_load()
     
        if i.radius>=dist:
            available_stantions.append(i)
        if load_st<=load_threashold and i.radius>=dist:
            ncl.append(i)

    
    if ncl:
        candidates=ncl
    else:
        candidates=available_stantions

    best_station = None
    best_rsrp_pilot = -math.inf
    types=[]

    if candidates:
        for station in candidates:
            
            distance = math.sqrt((user.x-station.x)**2+(user.y-station.y)**2)
            
            rsrp = 10**(calc_rsrp(station, distance)/10)
            n = max(1, len(station.connected_users))
            if station.type=='5G':
                rsrp_pilot=rsrp+15
            else:
                rsrp_pilot=rsrp
            
            types.append(station.type)
            if rsrp_pilot > best_rsrp_pilot:
                best_rsrp_pilot=rsrp_pilot
                best_station=station
    return best_station

def min_max(numbers):
    new_list=[]
    for i in numbers:
        n=(i-min(numbers))/(max(numbers)-min(numbers))
        new_list.append(n)
    return new_list


def scale(n,mini_max):
    min_val,max_val=mini_max
    return max(0.0,min(1.0,(n-min_val)/(max_val-min_val)))


def start_neat(stations,serving,net,handovers_prev_step):
    #placeholder 
    cio=random.randint(-10,10)
    del_ttt=random.uniform(-1,1)
    
    avg_load=0.0
    avg_throghput=0.0
    max_load=0.0
    avg_sinr=0.0
    for i in stations:
        i_load=i.get_load()
        if i_load>max_load:
                max_load=i_load
        if i.station_id !=serving.station_id:
            cur_through=0.0
            cur_sinr=0.0
            avg_load+=i_load
            
            
            for user in i.connected_users:
                cur_through+=user.throughput
                cur_sinr+=user.sinr
            if len(i.connected_users)>0:
                cur_sinr=cur_sinr/len(i.connected_users)
                cur_through=cur_through/len(i.connected_users)
            else:
                cur_through=0
            avg_throghput+=cur_through
            avg_sinr+=cur_sinr
    avg_throghput=avg_throghput/(len(stations)-1)
    avg_sinr=avg_sinr/(len(stations)-1)
    serving_through=0
    serving_sinr=0.0
    for users in serving.connected_users:
        serving_through+=users.throughput
        serving_sinr+=users.sinr
    if len(serving.connected_users)>0:

        serving_through=serving_through/len(serving.connected_users)
        serving_sinr=serving_sinr/len(serving.connected_users)
    else:
        serving_through=0
        serving_sinr=0
    avg_load=avg_load/(len(stations)-1)

    serving_laod=serving.get_load()
    if serving.type=="5G":
        is_5G=1
        freq=1
    else:
        is_5G=0
        freq=0

    inputs=[
        scale(is_5G,mini_max_dict['is_5G']),
        scale(serving_laod,mini_max_dict['load']),
        scale(avg_load,mini_max_dict['avg_load']),
        scale(max_load,mini_max_dict['max_load']),
        scale(serving_through,mini_max_dict['throughput']),
        scale(avg_throghput,mini_max_dict['avg_throughput']),
        scale(serving_sinr,mini_max_dict['sinr']),
        scale(avg_sinr,mini_max_dict['avg_sinr']),
        scale(handovers_prev_step,mini_max_dict['handovers_prev_step']),
    ]
    outputs = net.activate(inputs)
    ttt=ttt_base
    #print(f'inputs {inputs}')
    #print(f"Outзut {outputs[0]}")
    return outputs[0]*300,ttt

def calc_dist(station,user):
    user_x=user.x
    user_y=user.y
    station_x=station.x
    station_y=station.y
    dist=math.sqrt((user_x-station_x)**2+(user_y-station_y)**2)
    return dist




def simulation_step(stations, users,net):
    handover_hystory=[]
    handovers_this_step = 0
    min_sinr=100
    max_sinr=-100
    for station in stations:
        cio,ttt=start_neat(stations,station,net,handovers_this_step)
        station.CIO=cio
        
    
    for user in users:
        user.move()
      
        available_stantions=[]
        for i in stations:
            dist=calc_dist(i,user)
            if i.radius>=dist:
                available_stantions.append(i)
                
        best_station=None
        best_rsrp=-400
  
        if available_stantions:
            
            for i in available_stantions:
                dist=calc_dist(i,user)
                

                if i.CIO+calc_rsrp(i,dist)>best_rsrp:
                    best_rsrp=i.CIO+calc_rsrp(i,dist)
                    best_station=i
           
         
  
        if best_station:
            if user.serving_station_id!=best_station.station_id and user.del_ttt>ttt_base:
                old_station_id=-1
                if user.serving_station_id>= 0:
                    serving=stations[user.serving_station_id]
                    serving.remove_user(user)
                    old_station_id= serving.station_id

                user.steps_connected_list.append(user.steps_connected)
                user.steps_connected=1
                best_station.add_user(user)
                user.serving_station_id= best_station.station_id
                handovers_this_step+= 1
                user.del_ttt= 0.0
                handover_hystory.append((old_station_id, best_station.station_id))
                
            else:
                user.del_ttt+=time_in_step
                
                user.steps_connected+=1
        
    disconnected_users=0
    for user in users:
            if user.serving_station_id==-1:
                disconnected_users+=1
            serving= stations[user.serving_station_id]
            dist=math.sqrt((user.x-serving.x)**2+(user.y-serving.y)**2)
            if dist>serving.radius:
                serving.remove_user(user)

           
      

    return handovers_this_step,handover_hystory,disconnected_users






def compute_metrics(stations, users):
  
    throughputs=[]
    sinrs=[]
    sat=[]
    max_load=0
    load_5G=[]
    load_lte=[]
    ping_pong=0
    for station in stations:
        if station.type=="LTE":
            load_lte.append(station.get_load())
        elif station.type=="5G":
            load_5G.append(station.get_load())
        if station.get_load()>max_load:
            max_load=station.get_load()
    for user in users:
        if user.serving_station_id >= 0:
            throughputs.append(user.throughput)    
            sinrs.append(user.current_sinr) 
            sat.append(user.sat)
        if user.steps_connected_list:
            for k in user.steps_connected_list:
                if k<=3:
                    ping_pong+=1
                    user.user.steps_connected.clear()
        
    if throughputs:
        mean_throughputs=float(np.mean(throughputs))
    else:
        mean_throughputs=0
    if sinrs:
        mean_sinrs=float(np.mean(sinrs))
    else:
        mean_sinrs=0
    if sat:
        mean_sat=float(np.mean(sat))
    else:
        mean_sat=0
    return {"avg_load_lte":float(np.mean(load_lte)),"avg_load_5G":float(np.mean(load_5G)),"max_load": max_load,
            "avg_throughput":mean_throughputs,"avg_sinr":mean_sinrs,"avg_sat": mean_sat, "ping_pong": ping_pong}

def plot_results(stations, users, metrics_history, handover_history, G):

    plt.figure(figsize=(8, 8))

    for s in stations:
        color = 'blue' if s.type == '5G' else 'red'

        plt.gca().add_patch(
            plt.Circle((s.x, s.y), s.radius, color=color, alpha=0.1)
        )

        plt.plot(s.x, s.y, 's' if s.type == '5G' else '^',
                color=color, markersize=10)

    for u in users:
        plt.plot(u.x, u.y, 'ko', markersize=4)

    pos = nx.get_node_attributes(G, 'pos')

    for u_node, s_node in G.edges():
        if u_node in pos and s_node in pos:
            plt.plot(
                [pos[u_node][0], pos[s_node][0]],
                [pos[u_node][1], pos[s_node][1]],
                'gray',
                linewidth=0.5
            )

    plt.xlim(-500, 2500)
    plt.ylim(-500, 2500)
    plt.gca().set_aspect('equal')
    plt.title("Map")
    plt.show()

    steps = range(len(metrics_history))
    loads = [m["avg_load"] * 100 for m in metrics_history]

    plt.figure(figsize=(8, 4))
    plt.plot(steps, loads)
    plt.xlabel("Step")
    plt.ylabel("Load (%)")
    plt.title("Average Cell Load")
    plt.grid()
    plt.show()

    throughputs = [m["avg_throughput"] for m in metrics_history]

    plt.figure(figsize=(8, 4))
    plt.plot(steps, throughputs)
    plt.xlabel("Step")
    plt.ylabel("Throughput (Mbps)")
    plt.title("Average Throughput")
    plt.grid()
    plt.show()

    plt.figure(figsize=(8, 4))
    plt.bar(steps, handover_history)
    plt.xlabel("Step")
    plt.ylabel("Handovers")
    plt.title("Handovers per Step")
    plt.grid(axis='y')
    plt.show()


def run_simulation(net):
    
   

    stations = []

    lte_positions = [
        (900, 900),(1700, 1300),(1700, 500),
        (900, 100),(100, 1300),(100, 500),
        (900, 1700)
    ]
    for i, (x, y) in enumerate(lte_positions):
        stations.append(BaseStation(i, 'LTE', x, y))

    small_positions = []
    for i in lte_positions:
        i_x=i[0]
        i_y=i[1]
        small_positions.append((i_x-200,i_y))
        small_positions.append((i_x+150,i_y+200))
        small_positions.append((i_x+150,i_y-200))
    small_positions.append((350,1790))
    small_positions.append((1450,1790))
    small_positions.append((350,10))
    small_positions.append((1450,10))
    for i, (x, y) in enumerate(small_positions):
        stations.append(BaseStation(n_lte + i,'5G',x,y))


    users = []
    
    for i in range(n_user):
               sx=0
               sy=18*i
               tx=1799
               ty=18*i
               speed_kmh=130
               traffic_req=5
               users.append(User(i,sx,sy,tx,ty,speed_kmh,traffic_req))

    for user in users:
        target=find_target_station(user,stations)
        if target:
            target.add_user(user)
            user.serving_station_id=target.station_id
            user.current_sinr=calculate_sinr(user,target,stations)

    initial_metrics=compute_metrics(stations, users)
    
    n_disconected_user=0
    for user in users:
        if user.is_discon==True:
            n_disconected_user+=1
    metrics_history=[]
    handover_history=[]
    dicson_history=[n_disconected_user]
    total_handovers=0
    hanovers_over_steps=[]

    user_history=[]
    load_history=[]
    handover_hystory_total=[]
    disconnected_users_total=0

    step_par=[]

    ping_pong_history=0
    import true_rein
    for step in range(steps):
        
        n_disconected_user=0

        #FOR NEAT
        #ho_count,handover_hystory,disconnected_users=simulation_step(stations, users,net)
 
        
        #FOR learning
        
                
        ho_count,handover_hystory,disconnected_users=true_rein.run_algorithm(stations, users)





        hanovers_over_steps.append(ho_count)
        handover_hystory_total.extend(handover_hystory)
        metrics=compute_metrics(stations, users)

        for user in users:
            if user.is_discon==True:
                n_disconected_user+=1
        dicson_history.append(n_disconected_user)

        metrics_history.append(metrics)
        handover_history.append(ho_count)
        total_handovers+=ho_count

        ping=metrics["ping_pong"]
        ping_pong_history+=ping

        disconnected_users_total+=disconnected_users
        user_history.append([(u.user_id,u.x, u.y, u.serving_station_id,u.is_discon) for u in users])
        load_history.append([s.get_load() for s in stations])

        
        #if (step + 1) % 10 == 0 or step == 0:
            #print(f"step 200/{step}, avarage load: {metrics['avg_load']*100:5.1f}%,averege throughput: {metrics['avg_throughput']:5.2f} mbps, HO count: {ho_count}")

    
   
    anim
    st_x=[]
    st_y=[]
    st_type=[]
    st_rad=[]
    for station in stations:
        st_x.append(station.x)
        st_y.append(station.y)
        st_type.append(station.type)
        st_rad.append(station.radius)
    
    return ping_pong_history, disconnected_users_total,stations, users, metrics_history,user_history,load_history,st_x,st_y,st_type,st_rad,map,handover_history,hanovers_over_steps



def start(net,single):

        ping_pong_history, disconnected_users_total,stations, users, metrics_history,user_history,load_history,st_x,st_y,st_type,st_rad,map,handover_history,hanovers_over_steps = run_simulation(net)
        
    

    
        sim_avg_load_lte_list=[]
        sim_avg_load_5G_list=[]
        sim_max_load_list=[]
        sim_avg_throghput_list=[]
        sim_avg_sat_list=[]
    
        # return {"avg_load_lte":float(np.mean(load_lte)),"avg_load_5G":float(np.mean(load_5G)),"max_load": max_load,
                #    "avg_throughput":mean_throughputs,"avg_sinr":mean_sinrs,"avg_sat": mean_sat}
    
        for i in metrics_history:
            sim_avg_load_lte_list.append(i["avg_load_lte"])
            sim_avg_load_5G_list.append(i["avg_load_5G"])
            sim_max_load_list.append(i["max_load"])
            sim_avg_throghput_list.append(i["avg_throughput"])
            sim_avg_sat_list.append(i["avg_sat"])
    
        sim_avg_load_lte=np.mean(sim_avg_load_lte_list)
        sim_avg_load_5G=np.mean(sim_avg_load_5G_list)
        sim_max_load=np.mean(sim_max_load_list)
        sim_avg_throghput=np.mean(sim_avg_throghput_list)
        sim_avg_sat=np.mean(sim_avg_sat_list)
        if single==True:
                cfewf=input('Animate? 1 for yes, 0 for no\n')
                if cfewf=='1':
                    a=anim(user_history,load_history,st_x,st_y,st_type,st_rad,map+700)
                    a.working()
        
        return ping_pong_history, disconnected_users_total,sim_avg_load_lte,sim_avg_load_5G,sim_max_load,sim_avg_throghput,np.mean(hanovers_over_steps),sim_avg_sat


if __name__ == "__main__":
    t=5
    c=2
    
    
    stations, users, metrics_history,user_history,load_history,st_x,st_y,st_type,st_rad,map,handover_history,hanovers_over_steps = run_simulation()




    while True:
        cfewf=input('Animate? 1 for yes, 2 for no\n')
        if cfewf=='1':
            a=anim(user_history,load_history,st_x,st_y,st_type,st_rad,map)
            a.working()
            break
        elif cfewf=='2':
            break
    
    