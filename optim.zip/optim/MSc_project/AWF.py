
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.animation import FuncAnimation
import copy
from anim import anim
lte_r=500
lte_pow=46
n_lte=7
lte_prb=100
lte_freq_ghz=2.1
lte_bandwidth= 20


r_5G=200
p_5G=30
prb_5G=2500
n_5G=21
freq_5g_ghz=28
bandwidth_5g=500


one_prb=180*1000 
n_user=100


min_speed=1
max_speed=160
min_traf=1.0
max_traf=8.0

  
min_sinr=-8
max_sinr=25

min_hom=0
max_hom=300
sinr_threashhold=-10
load_threashold=0.5

map=1800
steps=200


noise_figure=6       
cons = -174 
sinr_max=25
noice_prb=cons+10*np.log10(one_prb)+noise_figure
ce=[
    0.1,0.1523,0.2344,0.3770,0.6016,0.8770,
    1.1758,1.4766,1.9141,2.4063,2.7305,3.3223,
    3.9023,4.5234,5.1152,5.5547
]
sinr_table=[
    (-np.inf,-6.7),(-6.7, -4.7),(-4.7 ,-2.3),(-2.3 , 0.2),(0.2, 2.4),(2.4 , 4.3),(4.3 ,5.9),(5.9, 8.1),
    (8.1,10.3),(10.3 , 11.7),(11.7, 14.1),(14.1 ,16.3),(16.3, 18.7),(18.7 , 21.0),(21.0 , 22.7),(22.7 , np.inf)
]
sinr_to_se_table=[
    (0,0,0),(0,0,0),(0,0,0),(0,0,0),(0,0,0),(0,0,0),(0,0,0),(0,0,0),
    (0,0,0),(0,0,0),(0,0,0),(0,0,0),(0,0,0),(0,0,0),(0,0,0),(0,0,0)
]
for i in range (len(sinr_table)):
    sinr_to_se_table[i]=ce[i],sinr_table[i][0],sinr_table[i][1]


time_in_step=0.4 
ttt_min=0.0
ttt_max=5.12
ttt_p=0.04
ttt_q=0.1    

class BaseStation:

    def __init__(self, station_id, type, x, y):
        
        self.station_id=station_id
        self.type=type
        self.x=x
        self.y=y
        self.load=0.0
        if type=='LTE':
            self.radius=lte_r
            self.power=lte_pow
            self.prb_total=lte_prb
            self.freq=lte_freq_ghz
            self.bandwidth=lte_bandwidth
        else:  
            self.radius=r_5G
            self.power=p_5G
            self.prb_total=prb_5G
            self.freq=freq_5g_ghz
            self.bandwidth=bandwidth_5g

        self.prb_used=0

        self.connected_users=[]

    def get_load(self):

        self.prb_used=0
        
        if self.type=="LTE":
            self.prb_total=lte_prb
        else:
            self.prb_total=prb_5G
        all_se=0
        se=0
        if len(self.connected_users)==0:
            return 0.0
 

        traffics=[]
        don=False
        b=0
        #print(f"used prb before loop {self.prb_used}")
        demand={}
        already_happened=False                           
        for user in self.connected_users:
            for i in sinr_to_se_table:
                if user.current_sinr>i[1] and user.current_sinr<i[2]:
                    b+=1

                    se=i[0]
                    user.se=se
                    one_prb_throughput=one_prb*se
                    import math
                    user_prb=math.ceil(user.traf_req*1_000_000/one_prb_throughput)
                    wanted=user_prb
                    demand[user]=wanted  
                        
                    if user_prb+self.prb_used>self.prb_total:
                       
                        user_prb=max(0, self.prb_total-self.prb_used)
                        if user_prb==0 and already_happened==False: 
                            already_happened=True 
                            equal_prb=np.floor(self.prb_total/len(self.connected_users))
                            user_prb=equal_prb
                            for i in self.connected_users:
                                
                                old_prb=i.prb
                                if old_prb==0:
                                    old_prb=1
                                old_sat=i.sat
                                i.prb=equal_prb

                                wanted_i=demand.get(i, old_prb)      
                                
                                if wanted_i>0:
                                    new_sat=min(1.0, equal_prb/wanted_i) 

                                else:
                                    new_sat=0.0 
                                i.sat=new_sat

                        elif user_prb==0 and already_happened==True: 
                            user_prb=equal_prb    
                                 
                        self.prb_used+=user_prb        
                        user.sat=min(1.0, user_prb/wanted)
                        user.prb=user_prb
                        user.throughput=user_prb*se
                    
                    else:
                        self.prb_used+=user_prb
                        user.prb=user_prb
                        user_prb_throughput=user_prb*se
                        user.throughput=user_prb_throughput
                        user.sat=1.0
                    
                    
                
        self.get_used_prb()
                   
        load=self.prb_used/self.prb_total

        
        self.load=load
       
        return load

    def get_used_prb(self):
        self.prb_used=0
        for user in self.connected_users:
            self.prb_used+=user.prb
        if self.prb_used>self.prb_total:
            print(f'what')
            for users in self.connected_users:
                print(users.prb)


    def is_overloaded(self):
        return self.get_load()>load_threashold

    def add_user(self, user):
        self.connected_users.append(user)
        user.is_discon=False
        

    def remove_user(self, user):
        if user in self.connected_users:
            self.connected_users.remove(user)
            user.is_discon=True
            user.prb=0
            user.throughput=0
            

class User:

    def __init__(self, user_id, x, y, target_x, target_y, speed_kmh,traffic_req):
        self.user_id=user_id
        self.x=x
        self.y=y
        self.target_x=target_x
        self.target_y=target_y
        self.speed_kms=speed_kmh
        self.speed_ms=(speed_kmh * 1000)/3600*time_in_step
        self.traf_req=traffic_req
        self.prb=0
        self.se=0
        self.serving_station_id=-1
        self.current_sinr=0.0
        self.throughput=0.0
        self.path_x=[x]
        self.path_y=[y]
        self.ttt_timer= 0.0
        self.ttt_t=0.0
        self.f_wf_prev= 0.0 
        self.is_discon=True
        self.sat=0.0

    def move(self):

        dx = self.target_x - self.x
        dy = self.target_y - self.y
        distance = np.sqrt(dx**2+ dy**2)  

        if distance < self.speed_ms:
            
            self.x = self.target_x
            self.y = self.target_y
            self.target_x = np.random.uniform(0, map)
            self.target_y = np.random.uniform(0, map)
        else:
            
            self.x += (dx / distance) * self.speed_ms
            self.y += (dy / distance) * self.speed_ms

        self.path_x.append(self.x)
        self.path_y.append(self.y)

def calc_received_power(station,dist):
    d_0 = 1
    l_0 = 20*np.log10(d_0) + 20*np.log10(station.freq * 1000000000) - 147.55
    if station.type=='LTE':
        path_loss_ex = 3.0
    else:
        path_loss_ex = 3.0

    l_d = l_0 + 10 * path_loss_ex * np.log10(max(dist, d_0))

    received_power = station.power - l_d
    
    return received_power


def calculate_sinr(user, station, all_stations):

    distance=np.sqrt((user.x-station.x)**2+(user.y-station.y)**2)
    received_power=calc_received_power(station,distance)

    signal= 10 ** (received_power / 10)
    
    interference = 0  
    for other in all_stations:
        if other.station_id != station.station_id:
            if other.freq==station.freq:
                dist=np.sqrt((user.x-other.x)**2+(user.y-other.y)**2)
                new_received_power=calc_received_power(other, dist)
                interference+=10**(new_received_power/10)
    
       
    bandwidth = station.bandwidth * 1_000_000

    noise_dbm = (-174 +10*np.log10(bandwidth) +noise_figure)

    noise = 10**(noise_dbm / 10)
 
    sinr_lin=signal/(interference+noise)
    sinr_db=10*np.log10(sinr_lin) 

    if sinr_db<min_sinr:
        sinr_db=min_sinr
    if sinr_db>max_sinr:
        sinr_db=max_sinr
    
    return sinr_db

def automatic_weight_function(fs):
    
    f_y=fs[0]
    f_prb=fs[1]
    f_v=fs[2]
    total=(1-f_y)+(1-f_prb)+(1-f_v)
    w_y=f_y/total
    w_prb=f_prb/total
    w_v=f_v/total
    return [w_y,w_prb,w_v]


def find_target_station(user, stations):
    distances=[]
    ncl=[]
    available_stantions=[]
    for i in stations:
        user_x=user.x
        user_y=user.y
        station_x=i.x
        station_y=i.y
        dist=np.sqrt((user_x-station_x)**2+(user_y-station_y)**2)
        if i.radius>=dist:
            available_stantions.append(i)
        if i.get_load()<=load_threashold and i.radius>=dist:
            ncl.append(i)
    
    if ncl:
        candidates=ncl
    else:
        candidates=available_stantions

    best_station = None
    best_rsrp_pilot = -np.inf

    for station in candidates:
        
        distance = np.sqrt((user.x-station.x)**2+(user.y-station.y)**2)
        
        rsrp = 10**(calc_received_power(station, distance)/10)
        n = max(1, len(station.connected_users))
        rsrp_pilot = rsrp * (station.prb_total / n)
        if rsrp_pilot > best_rsrp_pilot:
            best_rsrp_pilot=rsrp_pilot
            best_station=station
    return best_station


def handover_decision(user, serving, target, all_stations):
    
    if target is None or target.station_id == serving.station_id:
        return False

    
    sinr_s = calculate_sinr(user, serving, all_stations)
    sinr_t = calculate_sinr(user, target,  all_stations)
    f_y=(sinr_t-sinr_s)/sinr_max
    if f_y<-1:
        f_y=-1
    elif f_y>1:
        f_y=1
    
    prb_per_s = serving.prb_total/max(1,len(serving.connected_users))
    prb_per_t = target.prb_total/max(1,len(target.connected_users))
        
    f_prb=prb_per_t/target.prb_total-prb_per_s/serving.prb_total #slightly modified formula to consider differetn max prb
    if f_prb<-1:
        f_prb=-1
    elif f_prb>1:
        f_prb=1
    
    
    speed_kmh = user.speed_kms 
    f_v= 2*np.log2((speed_kmh+max_speed)/max_speed)-1
    if f_v<-1:
        f_v=-1
    elif f_v>1 :
        f_v=1


    
    weights = automatic_weight_function([f_y, f_prb, f_v])
    w_y, w_prb, w_v = weights
    w_t=w_y+ w_prb+ w_v
    new_w_y, new_w_prb, new_w_v=w_y/w_t,w_prb/w_t,w_v/w_t
    
    f_wf = f_y*new_w_y+ f_prb*new_w_prb+ f_v*new_w_v

    
    hom_avg = (min_hom + max_hom) / 2.0
  

    if sinr_t <= sinr_threashhold and sinr_s >= sinr_threashhold:
        delta_hom = hom_avg * (1 + w_prb * f_prb + w_v * f_v)

    elif sinr_s <= sinr_threashhold and sinr_t >= sinr_threashhold:
        delta_hom = hom_avg * (-1 + w_prb * f_prb + w_v * f_v)

    elif sinr_s <= sinr_threashhold and sinr_t <= sinr_threashhold:
        delta_hom = hom_avg * f_wf
    elif sinr_s >= sinr_threashhold and sinr_t >= sinr_threashhold:
        delta_hom = hom_avg * f_wf

    
    
    dist_s=np.sqrt((user.x-serving.x)**2+(user.y-serving.y)**2)
    dist_t=np.sqrt((user.x-target.x)**2 +(user.y-target.y)**2) 

    rsrp_s_linear=10**(calc_received_power(serving,dist_s)/10) 
    rsrp_t_linear=10**(calc_received_power(target,dist_t)/10)

    rsrp_pilot_s=rsrp_s_linear*(serving.prb_total/max(len(serving.connected_users),1))
    rsrp_pilot_t=rsrp_t_linear*(target.prb_total/max(len(target.connected_users),1))
    
    rsrp_pilot_s_db = 10*np.log10(rsrp_pilot_s)
    rsrp_pilot_t_db = 10*np.log10(rsrp_pilot_t)

    return rsrp_pilot_t_db + delta_hom > rsrp_pilot_s_db,f_wf


def delta_ttt(user, f_wf):
    t=user.ttt_t
    f_wf_prev=user.f_wf_prev
 
    if ttt_min<t<ttt_max:
        if f_wf<=f_wf_prev+ttt_q:
            new_t=t-ttt_p
          
        else:
            new_t=t+ttt_p
          

    elif t==ttt_min:
        if f_wf <= f_wf_prev + ttt_q:
            new_t = t
          
        else:
            new_t = t + ttt_p
           

    elif t==ttt_max:
        if f_wf <= f_wf_prev + ttt_q:
            new_t = t - ttt_p
        else:
            new_t = t
    
    if new_t>ttt_max:
        new_t=ttt_max
    elif new_t<ttt_min:
        new_t=ttt_min
 
    return new_t


def simulation_step(stations, users):
    handover_hystory=[]
    handovers_this_step = 0
    for user in users:
        user.move()

        
        if user.serving_station_id < 0:
            target = find_target_station(user, stations)
            if target:
                target.add_user(user)
                user.serving_station_id = target.station_id

        serving = stations[user.serving_station_id]

        target = find_target_station(user, stations)

        if target is None or target.station_id == serving.station_id:
            user.ttt_timer = 0.0

        else: 
            do_or_not,f_wf=handover_decision(user, serving, target, stations)
            
            if do_or_not:
                handover_hystory.append((serving.station_id, target.station_id))
                user.ttt_t=delta_ttt(user, f_wf)
                user.f_wf_prev=f_wf
 
                user.ttt_timer+=time_in_step

                if user.ttt_timer>=user.ttt_t:
                    serving.remove_user(user)
                    target.add_user(user)
                    user.serving_station_id=target.station_id
                    user.ttt_timer=0.0 
                    handovers_this_step+=1
            else:
                user.ttt_t=delta_ttt(user, f_wf)
                user.ttt_timer = 0.0
      

        
        current_station = stations[user.serving_station_id]
        user.current_sinr = calculate_sinr(user, current_station, stations)

        for i in sinr_to_se_table:
                if user.current_sinr>i[1] and user.current_sinr<i[2]:
                    se=i[0]
                    user.se=se
                    one_prb_throughput=one_prb*se
                    user_prb=np.ceil(user.traf_req*1_000_000/one_prb_throughput)
                    
                    user_prb_throughput=user_prb*se
                    user.throughput=user_prb_throughput
        for user in users:
            serving = stations[user.serving_station_id]
            dist=np.sqrt((user.x-serving.x)**2+(user.y-serving.y)**2)
            if dist>serving.radius:
                serving.remove_user(user)
                    
    return handovers_this_step,handover_hystory






def compute_metrics(stations, users):
  
    throughputs=[]
    sinrs=[]
    sat=[]
    max_load=0
    load_5G=[]
    load_lte=[]
    for station in stations:
        if station.type=="LTE":
            load_lte.append(station.load)
        elif station.type=="5G":
            load_5G.append(station.load)
        if station.load>max_load:
            max_load=station.load
    for user in users:
        if user.serving_station_id >= 0:
            throughputs.append(user.throughput)    
            sinrs.append(user.current_sinr) 
            sat.append(user.sat)
    if throughputs:
        mean_throughputs=float(np.mean(throughputs))
    else:
        mean_throughputs=0
    if sinrs:
        mean_sinrs=float(np.mean(sinrs))
    else:
        mean_sinrs=0
    if sat:
        mean_sat=float(np.mean(sat))
    else:
        mean_sat=0
    return {"avg_load_lte":float(np.mean(load_lte)),"avg_load_5G":float(np.mean(load_5G)),"max_load": max_load,
            "avg_throughput":mean_throughputs,"avg_sinr":mean_sinrs,"avg_sat": mean_sat}





def plot_results(stations, users, metrics_history, handover_history, G):

    plt.figure(figsize=(8, 8))

    for s in stations:
        color = 'blue' if s.type == '5G' else 'red'

        plt.gca().add_patch(
            plt.Circle((s.x, s.y), s.radius, color=color, alpha=0.1)
        )

        plt.plot(s.x, s.y, 's' if s.type == '5G' else '^',
                color=color, markersize=10)

    for u in users:
        plt.plot(u.x, u.y, 'ko', markersize=4)

    pos = nx.get_node_attributes(G, 'pos')

    for u_node, s_node in G.edges():
        if u_node in pos and s_node in pos:
            plt.plot(
                [pos[u_node][0], pos[s_node][0]],
                [pos[u_node][1], pos[s_node][1]],
                'gray',
                linewidth=0.5
            )

    plt.xlim(-500, 2500)
    plt.ylim(-500, 2500)
    plt.gca().set_aspect('equal')
    plt.title("Map")
    plt.show()

    steps = range(len(metrics_history))
    loads = [m["avg_load"] * 100 for m in metrics_history]

    plt.figure(figsize=(8, 4))
    plt.plot(steps, loads)
    plt.xlabel("Step")
    plt.ylabel("Load (%)")
    plt.title("Average Cell Load")
    plt.grid()
    plt.show()

    throughputs = [m["avg_throughput"] for m in metrics_history]

    plt.figure(figsize=(8, 4))
    plt.plot(steps, throughputs)
    plt.xlabel("Step")
    plt.ylabel("Throughput (Mbps)")
    plt.title("Average Throughput")
    plt.grid()
    plt.show()

    plt.figure(figsize=(8, 4))
    plt.bar(steps, handover_history)
    plt.xlabel("Step")
    plt.ylabel("Handovers")
    plt.title("Handovers per Step")
    plt.grid(axis='y')
    plt.show()


def run_simulation():

    stations = []

    lte_positions = [
        (900, 900),(1700, 1300),(1700, 500),
        (900, 100),(100, 1300),(100, 500),
        (900, 1700)
    ]
    for i, (x, y) in enumerate(lte_positions):
        stations.append(BaseStation(i, 'LTE', x, y))

    small_positions = []
    for i in lte_positions:
        i_x=i[0]
        i_y=i[1]
        small_positions.append((i_x-200,i_y))
        small_positions.append((i_x+150,i_y+200))
        small_positions.append((i_x+150,i_y-200))
    small_positions.append((350,1790))
    small_positions.append((1450,1790))
    small_positions.append((350,10))
    small_positions.append((1450,10))
    for i, (x, y) in enumerate(small_positions):
        stations.append(BaseStation(n_lte + i,'5G',x,y))


    users = []
    for i in range(n_user):
        sx=np.random.randint(0,map)
        sy=np.random.randint(0,map)
        tx=np.random.randint(0,map)
        ty=np.random.randint(0,map)
        speed_kmh=np.random.uniform(min_speed,max_speed)
        traffic_req=np.random.uniform(min_traf,max_traf)
        users.append(User(i,sx,sy,tx,ty,speed_kmh,traffic_req))

    for user in users:
        target=find_target_station(user,stations)
        if target:
            target.add_user(user)
            user.serving_station_id=target.station_id
            user.current_sinr=calculate_sinr(user,target,stations)

    initial_metrics=compute_metrics(stations, users)
    
    n_disconected_user=0
    for user in users:
        if user.is_discon==True:
            n_disconected_user+=1
    metrics_history=[]
    handover_history=[]
    dicson_history=[n_disconected_user]
    total_handovers=0

    user_history=[]
    load_history=[]
    handover_hystory_total=[]
    disconnected_users_total=0
    step_par=[]

    for step in range(steps):
        n_disconected_user=0
        ho_count,handover_hystory = simulation_step(stations, users)
        handover_hystory_total.extend(handover_hystory)
        metrics  = compute_metrics(stations, users)

        for user in users:
            if user.is_discon==True:
                n_disconected_user+=1
        dicson_history.append(n_disconected_user)

        metrics_history.append(metrics)
        handover_history.append(ho_count)
        total_handovers += ho_count
        disconnected_users_total+=n_disconected_user
        
        user_history.append([(u.user_id,u.x, u.y, u.serving_station_id,u.is_discon) for u in users])
        load_history.append([s.get_load() for s in stations])

        
    
    import anim

    st_x=[]
    st_y=[]
    st_type=[]
    st_rad=[]
    for station in stations:
        st_x.append(station.x)
        st_y.append(station.y)
        st_type.append(station.type)
        st_rad.append(station.radius)


    
  
    
    return disconnected_users_total,stations, users, metrics_history,user_history,load_history,st_x,st_y,st_type,st_rad,map,handover_history




if __name__ == "__main__":
    t=5
    c=2
    import time
    start=time.time()
    disconnected_users_total,stations, users, metrics_history,user_history,load_history,st_x,st_y,st_type,st_rad,map,handover_history = run_simulation()
    end=time.time()
    ttt_ff=end-start
    print(f'time {ttt_ff}')
    cfewf=input('Animate? 1 for yes, 2 for no\n')
    if cfewf=='1':
            a=anim(user_history,load_history,st_x,st_y,st_type,st_rad,map)
            a.working()
            
    elif cfewf=='2':
            print('stop')