import numpy as np
import math
import random
import itertools
import torch
import torch.nn as nn
from course import calc_dist,calc_rsrp,ttt_base,time_in_step,ce,sinr_table
 
cio_set=[-100,-50,0,50,100]
n_actions_per_station=len(cio_set)
n_hidden=3
dropout_q=0.5
eps_decay=0.995
discount=1.0
lr=0.001
n_mcs=len(ce)

device = torch.device('cuda')


 
def build_blocks(stations):
    lte_stations=[]

    for s in stations:
        if s.type=='LTE':
            lte_stations.append(s)

    blocks=[]
    block_lte={}
    for lte in lte_stations:
        blocks.append([lte])
        block_lte[lte.station_id]=len(blocks)-1
 
    for s in stations:
        if s.type=='LTE':
            continue
        nearest_lte=None
        nearest_dist=None
        for lte in lte_stations:
            d=calc_dist(lte,s)
            if nearest_dist is None or d<nearest_dist:
                nearest_dist=d
                nearest_lte=lte
        block_index=block_lte[nearest_lte.station_id]
        blocks[block_index].append(s)
 
    return blocks
 
 
class rl_network(nn.Module):
 
    def __init__(self,input_size,n_stations_in_block):
        super().__init__()
        self.n_stations_in_block=n_stations_in_block
        output_size=n_actions_per_station**n_stations_in_block
        hidden=max(input_size,output_size)
        layers=[]
        prev=input_size
        for _ in range(n_hidden):
            layers+=[nn.Linear(prev,hidden),nn.ReLU(),nn.Dropout(dropout_q)]
            prev=hidden
        layers.append(nn.Linear(prev,output_size))
        self.net=nn.Sequential(*layers)
 
    def forward(self,x):
        logits=self.net(x)
        return torch.softmax(logits,dim=0)
 

def get_vector(station):
    vec=np.zeros(n_mcs,dtype=np.float32)
    n=len(station.connected_users)
    if n==0:
        return vec
    for user in station.connected_users:
        for i in range(n_mcs):
            if user.current_sinr>sinr_table[i][0] and user.current_sinr<=sinr_table[i][1]:
                vec[i]+=1
                break
    return vec/n
 
 
def calc_state(block):
    u=[]
    r=[]
    m=[]
    for s in block:
        u.append(s.get_load())
        through=[]
        for usr in s.connected_users:
            through.append(usr.throughput)
        if through:
            avg_through=sum(through)/len(through)
        else:
            avg_through=0.0
        r.append(avg_through/8.0)
        m.append(get_vector(s))
    state=np.concatenate([np.array(u,dtype=np.float32),np.array(r,dtype=np.float32),np.concatenate(m)])
    return torch.tensor(state,dtype=torch.float32,device=device)
 
 
def select_action_index(probs,eps_value):
    if random.random()<eps_value:
        return random.randint(0,probs.shape[0]-1)
    return int(torch.argmax(probs).item())
 
 
def train_block(block_index,current_state):
    rl_net=rl_nets[block_index]
    optimizer=optimizers[block_index]
    probs_prev=rl_net(prev_states[block_index])
    with torch.no_grad():
        next_max=rl_net(current_state).max()
    target=probs_prev.detach().clone()
    q_target=prev_rewards[block_index]+discount*next_max.item()
    row=probs_prev.detach().clone()
    row[prev_actions[block_index]]=q_target
    target=torch.softmax(row,dim=0)
    loss=-(target*torch.log(probs_prev+1e-8)).sum()
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
 
 
blocks=None
action_lists=None
rl_nets=None
optimizers=None
prev_states=None
prev_actions=None
prev_rewards=None
eps=None
step_index=None
 
 
def run_algorithm(stations,users):
    global blocks, action_lists, rl_nets, optimizers, prev_states, prev_actions, prev_rewards, eps, step_index
  
    if blocks is None:
        blocks=build_blocks(stations)
        action_lists=[]
        rl_nets=[]
        optimizers=[]
        prev_states=[]
        prev_actions=[]
        prev_rewards=[]
        for block in blocks:
            action_list=list(itertools.product(cio_set,repeat=len(block)))
            input_size=2*len(block)+len(block)*n_mcs
            net=rl_network(input_size,len(block)).to(device)
            action_lists.append(action_list)
            rl_nets.append(net)
            optimizers.append(torch.optim.Adam(net.parameters(),lr=lr))
            prev_states.append(None)
            prev_actions.append(None)
            prev_rewards.append(None)
        step_index=0
        eps=eps_decay**step_index
 
    chosen_actions=[]
    for id,block in enumerate(blocks):
        state=calc_state(block)
 
        if prev_states[id] is not None:
            rl_nets[id].train()
            train_block(id,state)
 
        rl_nets[id].eval()
        with torch.no_grad():
            probs=rl_nets[id](state)
        action_index=select_action_index(probs,eps)
        chosen_combo=action_lists[id][action_index]
        for i,station in enumerate(block):
            station.CIO=chosen_combo[i]
 
        chosen_actions.append(action_index)
        prev_states[id]=state
 
    handover_hystory=[]
    handovers_this_step=0
    for user in users:
        user.move()
        available=[]
        for s in stations:
            if s.radius>=calc_dist(s,user):
                available.append(s)

        serving_score=-math.inf
        if user.serving_station_id>=0:
            serving=stations[user.serving_station_id]
            if serving.radius>=calc_dist(serving,user):
                serving_score=serving.CIO+calc_rsrp(serving,calc_dist(serving,user))

        best_station=None
        best_rsrp=-400
        for s in available:
            score=s.CIO+calc_rsrp(s,calc_dist(s,user))
            if score>best_rsrp:
                best_rsrp=score
                best_station=s

        if best_station:
            meets_hysteresis = best_rsrp > serving_score + 3 
            if user.serving_station_id!=best_station.station_id and meets_hysteresis and user.del_ttt>ttt_base:
                old_station_id=-1
                if user.serving_station_id>=0:
                    serving=stations[user.serving_station_id]
                    serving.remove_user(user)
                    old_station_id=serving.station_id
                best_station.add_user(user)
                user.serving_station_id=best_station.station_id
                handovers_this_step+=1
                user.del_ttt=0.0
                handover_hystory.append((old_station_id,best_station.station_id))
            else:
                user.del_ttt+=time_in_step
 
    disconnected_users=0
    for user in users:
        if user.serving_station_id==-1:
            disconnected_users+=1
        else:
            serving=stations[user.serving_station_id]
            if calc_dist(serving,user)>serving.radius:
                serving.remove_user(user)
                disconnected_users+=1
 
    for st in stations:
        st.get_load()
 
    for id,block in enumerate(blocks):
        total_throughput=0.0
        for s in block:
            for user in s.connected_users:
                total_throughput+=user.throughput
        prev_rewards[id]=total_throughput
        prev_actions[id]=chosen_actions[id]
 
    step_index+=1
    eps=eps_decay**step_index 
 
    return handovers_this_step,handover_hystory,disconnected_users